# Changing Face Rating

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/YzLQoXM](https://codepen.io/jkantner/pen/YzLQoXM).

An emotional rating that involves a trick of setting a negative delay for animations while paused. CSS variables are also used to set the color tones.